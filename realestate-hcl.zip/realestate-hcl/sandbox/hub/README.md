<!-- BEGIN_TF_DOCS -->
<pre style="background: white;margin: 0;padding: 0">
╔═══╗         ╔╗     ╔═══╗     ╔╗       ╔╗         ╔═══╗╔╗           ╔╗
║╔═╗║         ║║     ║╔══╝    ╔╝╚╗     ╔╝╚╗        ║╔═╗║║║           ║║
║╚═╝║╔══╗╔══╗ ║║     ║╚══╗╔══╗╚╗╔╝╔══╗ ╚╗╔╝╔══╗    ║║ ╚╝║║ ╔══╗╔╗╔╗╔═╝║
║╔╗╔╝║╔╗║╚ ╗║ ║║     ║╔══╝║══╣ ║║ ╚ ╗║  ║║ ║╔╗║    ║║ ╔╗║║ ║╔╗║║║║║║╔╗║
║║║╚╗║║═╣║╚╝╚╗║╚╗    ║╚══╗╠══║ ║╚╗║╚╝╚╗ ║╚╗║║═╣    ║╚═╝║║╚╗║╚╝║║╚╝║║╚╝║
╚╝╚═╝╚══╝╚═══╝╚═╝    ╚═══╝╚══╝ ╚═╝╚═══╝ ╚═╝╚══╝    ╚═══╝╚═╝╚══╝╚══╝╚══╝
</pre>
# HUB
[ *auto-generated from git-rev. 183d0e1 on Wednesday, May 26 2021 - 21:22:04 IST* ] 
```

```

<hr>

## Requirements

The following requirements are needed by this module:

- <a name="requirement_terraform"></a> [terraform](#requirement_terraform) (>= 0.15.0)

- <a name="requirement_azuread"></a> [azuread](#requirement_azuread) (1.4.0)

- <a name="requirement_azurerm"></a> [azurerm](#requirement_azurerm) (2.54.0)

- <a name="requirement_local"></a> [local](#requirement_local) (2.1.0)

- <a name="requirement_random"></a> [random](#requirement_random) (3.1.0)

## Providers

The following providers are used by this module:

- <a name="provider_azuread"></a> [azuread](#provider_azuread) (1.4.0)

- <a name="provider_azurerm"></a> [azurerm](#provider_azurerm) (2.54.0)

- <a name="provider_terraform"></a> [terraform](#provider_terraform)

## Modules

The following Modules are called:

### <a name="module__"></a> [_](#module__)

Source: git::https://msci-otw@dev.azure.com/msci-otw/realestate-apps/_git/re-azure//modules/

Version:

### <a name="module_bootstrap"></a> [bootstrap](#module_bootstrap)

Source: ./.terraform/modules/_/modules/bootstrap

Version:

### <a name="module_naming"></a> [naming](#module_naming)

Source: ./.terraform/modules/_/modules/resource-naming

Version:

### <a name="module_publish_status"></a> [publish_status](#module_publish_status)

Source: ./.terraform/modules/_/modules/publish-status

Version:

## Resources

The following resources are used by this module:

- [azurerm_resource_group.resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/2.54.0/docs/resources/resource_group) (resource)
- [azurerm_storage_account.storage](https://registry.terraform.io/providers/hashicorp/azurerm/2.54.0/docs/resources/storage_account) (resource)
- [azurerm_storage_container.storage_container](https://registry.terraform.io/providers/hashicorp/azurerm/2.54.0/docs/resources/storage_container) (resource)
- [azuread_group.subscription_owners](https://registry.terraform.io/providers/hashicorp/azuread/1.4.0/docs/data-sources/group) (data source)
- [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/2.54.0/docs/data-sources/client_config) (data source)
- [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/2.54.0/docs/data-sources/subscription) (data source)
- [azurerm_virtual_network.network](https://registry.terraform.io/providers/hashicorp/azurerm/2.54.0/docs/data-sources/virtual_network) (data source)
- [terraform_remote_state.import](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) (data source)

## Required Inputs

The following input variables are required:

### <a name="input_environment"></a> [environment](#input_environment)

Description: n/a

Type:

```hcl
object({
    hub = object({
      sequence = string, primary_key = string
    })
    import = list(object({
      sequence = string, primary_key = string, as = string
    }))
    metadata = object({
      sequence = string, primary_key = string, contact = string, source = string
    })
  })
```

### <a name="input_network"></a> [network](#input_network)

Description: n/a

Type:

```hcl
object({
    resource_group = string, virtual_network = string
  })
```

## Optional Inputs

The following input variables are optional (have default values):

### <a name="input_WEBHOOK"></a> [WEBHOOK](#input_WEBHOOK)

Description: n/a

Type: `string`

Default: `null`

### <a name="input_resource"></a> [resource](#input_resource)

Description: n/a

Type:

```hcl
object({
    tags = map(string), naming = object({
      environment = string, region = string, product = string
    })
  })
```

Default:

```json
{
  "naming": {
    "environment": "d",
    "product": "re",
    "region": "va2"
  },
  "tags": {
    "opsLifecycle": "short-lived",
    "opsSupportDl": "RealEstate_CloudEngineering@msci.com"
  }
}
```

## Outputs

The following outputs are exported:

### <a name="output_resource_group"></a> [resource_group](#output_resource_group)

Description: n/a

### <a name="output_storage"></a> [storage](#output_storage)

Description: n/a

### <a name="output_storage_container"></a> [storage_container](#output_storage_container)

Description: n/a

### <a name="output_virtual_network"></a> [virtual_network](#output_virtual_network)

Description: n/a
<!-- END_TF_DOCS -->